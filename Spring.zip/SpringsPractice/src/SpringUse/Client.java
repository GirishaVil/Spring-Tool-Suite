package SpringUse;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
public class Client {

	public static void main(String[] args) {
		
		//Object construction done by developer
		Employee eRef = new Employee();
		eRef.setId(101);
		eRef.setName("John Watson");
		eRef.setAddress("Redwood Shares");
		System.out.println("Employee Details from Object Constructor: "+eRef);
		
		//Spring IOC Object Creation
		Resource res= new ClassPathResource("bean.xml");
		BeanFactory factory = new XmlBeanFactory(res);
		
		Employee emp1 = (Employee) factory.getBean("emp1");
		System.out.println("Employee Details: "+emp1);
		
		Employee emp2 = factory.getBean("emp2",Employee.class);
		System.out.println("Employee Details: "+emp2);
	}
}
