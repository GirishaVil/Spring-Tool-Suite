package basic;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import basic.model.Person;
import basic.service.PersonService;

@SpringBootApplication
public class DataJpaApp implements CommandLineRunner {

	private static final Logger LOG = LoggerFactory.getLogger("JCG");

	@Autowired
	private PersonService service;

	public static void main(String[] args) {
		SpringApplication.run(DataJpaApp.class, args);
	}

	@Override
	public void run(String... strings) {
		
		System.out.println("Counting number of entries at start of CRUD");
		LOG.info("Current objects in DB: {}", service.countPersons());
		
		System.out.println("Inserting the records in DB");
		Person person1 = service.createPerson(new Person("Girisha", 23));
		Person person2 = service.createPerson(new Person("Geethanjali", 29));
		LOG.info("Person created in DB : {}", person1);
		LOG.info("Person created in DB : {}", person2);
		
		LOG.info("Current objects in DB: {}", service.countPersons());
		
		System.out.println("Editing the records in DB");
		person1.setName("Pratap");
		Person editedPerson = service.editPerson(person1);
		LOG.info("Person edited in DB  : {}", person1);

		System.out.println("Deleting the records in DB");
		service.deletePerson(person1);
		LOG.info("After deletion, count: {}", service.countPersons());
	}
}
